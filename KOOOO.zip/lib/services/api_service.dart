import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class ApiService {
  // ✅ ตรวจสอบ URL ให้ตรงกับ Ngrok ปัจจุบันของคุณ
  final String baseUrl =
      "https://misleading-unexpeditiously-exie.ngrok-free.dev/api";

  // 1. ฟังก์ชันดึงข้อมูลสินค้า (คงเดิม)
  Future<List<dynamic>> getProducts() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/get_products.php"),
        headers: {"ngrok-skip-browser-warning": "true"},
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
    } catch (e) {
      print("Error fetching products: $e");
    }
    return [];
  }

  // 2. ฟังก์ชันสมัครสมาชิก (คงเดิม)
  Future<bool> register(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/register.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"email": email, "password": password}),
      );
      return response.statusCode == 200 && response.body.contains("success");
    } catch (e) {
      return false;
    }
  }

  // 3. ฟังก์ชัน Login (คงเดิม)
  Future<dynamic> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/login.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"email": email, "password": password}),
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        if (data['status'] == "success") {
          return data['role'];
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // 4. ฟังก์ชันเพิ่มสินค้า (คงเดิม)
  Future<bool> addProduct(String name, String price, String qty, String image,
      String description) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/add_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({
          "name": name,
          "price": price,
          "qty": qty,
          "image": image,
          "description": description,
        }),
      );
      return response.body.contains("success");
    } catch (e) {
      return false;
    }
  }

  // 5. ฟังก์ชันลบสินค้า (คงเดิม)
  Future<bool> deleteProduct(int id) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/delete_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"id": id}),
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // 6. ฟังก์ชันแก้ไขสินค้า (คงเดิม)
  Future<bool> updateProduct(int id, String name, String price, String qty,
      String image, String description) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/update_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({
          "id": id,
          "name": name,
          "price": price,
          "description": description,
          "qty": qty,
          "image": image
        }),
      );
      return response.statusCode == 200 && response.body.contains("success");
    } catch (e) {
      return false;
    }
  }

  // 7. ฟังก์ชันซื้อสินค้า (คงเดิม)
  Future<bool> buyProduct(
      String productId, String qty, double total, String paymentMethod) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/buy_product.php"),
        headers: {"ngrok-skip-browser-warning": "true"},
        body: {
          "product_id": productId,
          "qty": qty,
          "total_price": total.toString(),
          "payment_method": paymentMethod,
        },
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // 8. ฟังก์ชันดึงประวัติการซื้อ (คงเดิม)
  Future<List<dynamic>> getPurchaseHistory() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/get_orders.php"),
        headers: {"ngrok-skip-browser-warning": "true"},
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // ✅ 9. ฟังก์ชันบันทึกประวัติการซื้อ (แก้ไขเพื่อรับ paymentMethod)
  Future<bool> recordOrder(String productName, int buyQty, double totalPrice,
      String paymentMethod) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/save_order.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({
          "product_name": productName,
          "qty": buyQty,
          "total_price": totalPrice,
          "payment_method": paymentMethod, // ส่งค่าช่องทางชำระเงินไปยัง Server
        }),
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // 10. ฟังก์ชันอัปโหลดรูปภาพ (คงเดิม)
  Future<String?> uploadImage(XFile pickedFile) async {
    try {
      var uri = Uri.parse("$baseUrl/upload_image.php");
      var request = http.MultipartRequest('POST', uri);
      request.headers['ngrok-skip-browser-warning'] = 'true';

      var bytes = await pickedFile.readAsBytes();
      var multipartFile = http.MultipartFile.fromBytes(
        'image',
        bytes,
        filename: pickedFile.name,
      );

      request.files.add(multipartFile);
      var response = await request.send();
      var resData = await response.stream.bytesToString();

      if (response.statusCode == 200) {
        if (resData.contains('{')) {
          var jsonRes = jsonDecode(resData);
          return jsonRes['url'];
        }
      }
    } catch (e) {
      print("Upload Error Details: $e");
    }
    return null;
  }
}
