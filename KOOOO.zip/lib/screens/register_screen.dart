import 'package:flutter/material.dart';
import '../services/api_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController _userController = TextEditingController();
  final TextEditingController _passController = TextEditingController();
  bool _isLoading = false;

  void _register() async {
    if (_userController.text.trim().isEmpty ||
        _passController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("กรุณากรอก Username และ Password")),
      );
      return;
    }

    setState(() => _isLoading = true);

    bool success = await ApiService()
        .register(_userController.text.trim(), _passController.text.trim());

    if (!mounted) return;
    setState(() => _isLoading = false);

    if (success) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("สมัครสมาชิกสำเร็จ")));
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("สมัครสมาชิกไม่สำเร็จ!")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar โทนสี Gradient เดียวกับหน้า Home และ Login
      appBar: AppBar(
        title: const Text("สร้างบัญชีใหม่",
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blueAccent, Colors.purpleAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Container(
        color: Colors.grey.shade50,
        padding: const EdgeInsets.all(25.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Icon สัญลักษณ์การสมัครสมาชิก
                const Icon(Icons.person_add_alt_1_rounded,
                    size: 100, color: Colors.purpleAccent),
                const SizedBox(height: 10),
                const Text("เข้าร่วมกับเรา",
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueGrey)),
                const Text("กรอกข้อมูลเพื่อเริ่มต้นใช้งานระบบคลังสินค้า",
                    style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 40),

                // ช่องกรอกข้อมูลสไตล์ขอบมน
                _buildTextField(
                    _userController, "Username / Email", Icons.person_outline),
                const SizedBox(height: 15),
                _buildTextField(
                    _passController, "Password", Icons.lock_open_rounded,
                    obscure: true),

                const SizedBox(height: 30),

                // ปุ่มลงทะเบียนแบบไล่เฉดสี
                _isLoading
                    ? const CircularProgressIndicator(
                        color: Colors.purpleAccent)
                    : GestureDetector(
                        onTap: _register,
                        child: Container(
                          height: 55,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Colors.purpleAccent, Colors.blueAccent],
                            ),
                            borderRadius: BorderRadius.circular(15),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.blueAccent.withOpacity(0.3),
                                blurRadius: 10,
                                offset: const Offset(0, 5),
                              )
                            ],
                          ),
                          child: const Center(
                            child: Text("ลงทะเบียน",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),

                const SizedBox(height: 20),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("มีบัญชีอยู่แล้ว? กลับไปหน้าเข้าสู่ระบบ",
                      style: TextStyle(color: Colors.blueAccent)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ฟังก์ชันช่วยสร้าง TextField ให้ดูสวยงาม (Reuse จากหน้า Login)
  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon,
      {bool obscure = false}) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.purpleAccent),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
        filled: true,
        fillColor: Colors.white,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Colors.purpleAccent, width: 2),
        ),
      ),
    );
  }
}
