import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import 'add_product_screen.dart';
import 'login_screen.dart';
import 'order_history_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool isAdmin = false;
  XFile? _selectedXFile;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _checkRole();
  }

  Future<void> _checkRole() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isAdmin = prefs.getString('role') == 'admin';
    });
  }

  String _formatImageUrl(String url) {
    if (url.isEmpty) return "";
    if (url.contains('ngrok-free.app')) {
      String cleanUrl =
          url.replaceFirst('https://', '').replaceFirst('http://', '');
      return "https://images.weserv.nl/?url=$cleanUrl";
    }
    return url;
  }

  // --- 1. แสดงรายละเอียดสินค้า (ปรับดีไซน์ใหม่ให้พรีเมียม) ---
  void _showProductDetails(Map<String, dynamic> item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        contentPadding: EdgeInsets.zero,
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ClipRRect(
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(25)),
                child: Image.network(
                  _formatImageUrl(item['image'] ?? ''),
                  height: 250,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (c, e, s) => Container(
                      height: 250,
                      color: Colors.grey[100],
                      child: const Icon(Icons.broken_image,
                          size: 50, color: Colors.grey)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['name'] ?? '',
                        style: const TextStyle(
                            fontSize: 24, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text("฿${item['price']}",
                        style: const TextStyle(
                            fontSize: 22,
                            color: Colors.blueAccent,
                            fontWeight: FontWeight.bold)),
                    const Divider(height: 30),
                    const Text("รายละเอียดสินค้า",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Colors.black54)),
                    const SizedBox(height: 8),
                    Text(
                      (item['description'] == null ||
                              item['description'].toString().trim().isEmpty)
                          ? ""
                          : item['description'].toString(),
                      style: TextStyle(
                          color: Colors.grey[800], height: 1.5, fontSize: 15),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        const Icon(Icons.inventory_2_outlined,
                            size: 18, color: Colors.grey),
                        const SizedBox(width: 8),
                        Text("สินค้าคงเหลือในคลัง: ${item['qty']} ชิ้น",
                            style: const TextStyle(
                                color: Colors.grey,
                                fontWeight: FontWeight.w500)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("ปิดหน้าต่าง",
                  style: TextStyle(color: Colors.grey))),
        ],
      ),
    );
  }

  // --- 2. การซื้อสินค้า (คงเดิมแต่ปรับ UI ปุ่ม) ---
  void _buyProduct(Map<String, dynamic> item) {
    final qtyPurchaseController = TextEditingController(text: "1");
    int currentQty = int.tryParse(item['qty'].toString()) ?? 0;
    double unitPrice = double.tryParse(item['price'].toString()) ?? 0.0;
    String selectedPayment = 'เงินสด';
    final List<String> paymentOptions = [
      'เงินสด',
      'โอนเงิน 620-3-21175',
      'พร้อมเพย์ 0640163548'
    ];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          int buyAmount = int.tryParse(qtyPurchaseController.text) ?? 0;
          double totalAmount = unitPrice * buyAmount;

          return AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Text("สั่งซื้อ ${item['name']}"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: qtyPurchaseController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: "ระบุจำนวน", border: OutlineInputBorder()),
                  onChanged: (value) => setDialogState(() {}),
                ),
                const SizedBox(height: 15),
                DropdownButtonFormField<String>(
                  value: selectedPayment,
                  decoration: const InputDecoration(
                      labelText: "วิธีชำระเงิน", border: OutlineInputBorder()),
                  items: paymentOptions
                      .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                      .toList(),
                  onChanged: (v) => setDialogState(() => selectedPayment = v!),
                ),
                const SizedBox(height: 10),
                Text("ราคารวม: ฿${totalAmount.toStringAsFixed(2)}",
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.green)),
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("ยกเลิก")),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent),
                onPressed: () async {
                  if (buyAmount <= 0 || buyAmount > currentQty) return;
                  bool success = await ApiService().updateProduct(
                    int.parse(item['id'].toString()),
                    item['name'],
                    item['price'].toString(),
                    (currentQty - buyAmount).toString(),
                    item['image'] ?? '',
                    item['description'] ?? '',
                  );
                  if (success) {
                    await ApiService().recordOrder(
                        item['name'], buyAmount, totalAmount, selectedPayment);
                    Navigator.pop(context);
                    setState(() {});
                  }
                },
                child: const Text("ยืนยันการซื้อ",
                    style: TextStyle(color: Colors.white)),
              ),
            ],
          );
        },
      ),
    );
  }

  // --- 3. แก้ไขสินค้า (จัดระเบียบช่องกรอกข้อมูล) ---
  void _showEditDialog(Map<String, dynamic> item) {
    final nameController = TextEditingController(text: item['name'].toString());
    final priceController =
        TextEditingController(text: item['price'].toString());
    final qtyController = TextEditingController(text: item['qty'].toString());
    final descController =
        TextEditingController(text: item['description']?.toString() ?? '');
    String currentImg = item['image'] ?? '';
    _selectedXFile = null;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text("แก้ไขข้อมูลสินค้า"),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: "ชื่อสินค้า")),
                TextField(
                    controller: descController,
                    maxLines: 2,
                    decoration: const InputDecoration(labelText: "รายละเอียด")),
                TextField(
                    controller: priceController,
                    decoration: const InputDecoration(labelText: "ราคา"),
                    keyboardType: TextInputType.number),
                TextField(
                    controller: qtyController,
                    decoration:
                        const InputDecoration(labelText: "จำนวนคงเหลือ"),
                    keyboardType: TextInputType.number),
                const SizedBox(height: 20),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: SizedBox(
                    height: 120,
                    child: _selectedXFile != null
                        ? Image.network(_selectedXFile!.path)
                        : Image.network(_formatImageUrl(currentImg),
                            errorBuilder: (c, e, s) =>
                                const Icon(Icons.image, size: 50)),
                  ),
                ),
                TextButton.icon(
                    icon: const Icon(Icons.photo_library),
                    onPressed: () async {
                      final XFile? img =
                          await _picker.pickImage(source: ImageSource.gallery);
                      if (img != null)
                        setDialogState(() => _selectedXFile = img);
                    },
                    label: const Text("เปลี่ยนรูปภาพ")),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("ยกเลิก")),
            ElevatedButton(
              onPressed: () async {
                String url = currentImg;
                if (_selectedXFile != null) {
                  String? up = await ApiService().uploadImage(_selectedXFile!);
                  if (up != null) url = up;
                }
                await ApiService().updateProduct(
                  int.parse(item['id'].toString()),
                  nameController.text,
                  priceController.text,
                  qtyController.text,
                  url,
                  descController.text,
                );
                Navigator.pop(context);
                setState(() {});
              },
              child: const Text("บันทึก"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        elevation: 0,
        title: const Text("คลังสินค้าออนไลน์",
            style: TextStyle(fontWeight: FontWeight.bold)),
        flexibleSpace: Container(
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [Colors.blueAccent, Colors.purpleAccent]))),
        actions: [
          if (isAdmin)
            IconButton(
                icon: const Icon(Icons.history),
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (c) => const OrderHistoryScreen()))),
          IconButton(
              icon: const Icon(Icons.logout),
              onPressed: () async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (c) => const LoginScreen()));
              }),
        ],
      ),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService().getProducts(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (!snapshot.hasData || snapshot.data!.isEmpty)
            return const Center(child: Text("ยังไม่มีสินค้าในระบบ"));

          return GridView.builder(
            padding: const EdgeInsets.all(15),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                childAspectRatio: 0.75),
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final item = snapshot.data![index];
              return Card(
                elevation: 4,
                shadowColor: Colors.black26,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18)),
                child: InkWell(
                  onTap: () => _showProductDetails(item),
                  borderRadius: BorderRadius.circular(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Stack(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(18)),
                              child: Image.network(
                                _formatImageUrl(item['image'] ?? ''),
                                width: double.infinity,
                                height: double.infinity,
                                fit: BoxFit.cover,
                                errorBuilder: (c, e, s) => const Center(
                                    child: Icon(Icons.broken_image,
                                        size: 40, color: Colors.grey)),
                              ),
                            ),
                            if (isAdmin)
                              Positioned(
                                top: 8,
                                right: 8,
                                child: Row(
                                  children: [
                                    _buildActionIcon(Icons.edit, Colors.blue,
                                        () => _showEditDialog(item)),
                                    const SizedBox(width: 5),
                                    _buildActionIcon(Icons.delete, Colors.red,
                                        () => _confirmDelete(item)),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item['name'] ?? '',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 15),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            Text("฿${item['price']}",
                                style: const TextStyle(
                                    color: Colors.blueAccent,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16)),
                            const SizedBox(height: 4),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("คงเหลือ: ${item['qty']}",
                                    style: TextStyle(
                                        fontSize: 12, color: Colors.grey[600])),
                                if (!isAdmin)
                                  GestureDetector(
                                    onTap: () => _buyProduct(item),
                                    child: const Icon(Icons.add_shopping_cart,
                                        color: Colors.orange, size: 22),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: isAdmin
          ? FloatingActionButton.extended(
              backgroundColor: Colors.purpleAccent,
              onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (c) => const AddProductScreen()))
                  .then((_) => setState(() {})),
              label: const Text("เพิ่มสินค้า"),
              icon: const Icon(Icons.add))
          : null,
    );
  }

  Widget _buildActionIcon(IconData icon, Color color, VoidCallback onTap) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.9), shape: BoxShape.circle),
      child: IconButton(
        constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
        padding: EdgeInsets.zero,
        icon: Icon(icon, size: 16, color: color),
        onPressed: onTap,
      ),
    );
  }

  void _confirmDelete(Map<String, dynamic> item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("ยืนยันการลบสินค้า"),
        content: Text("คุณต้องการลบ ${item['name']} ใช่หรือไม่?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("ยกเลิก")),
          TextButton(
              onPressed: () async {
                await ApiService()
                    .deleteProduct(int.parse(item['id'].toString()));
                Navigator.pop(context);
                setState(() {});
              },
              child: const Text("ลบออก", style: TextStyle(color: Colors.red))),
        ],
      ),
    );
  }
}
