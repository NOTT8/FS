import 'package:flutter/material.dart';
import '../services/api_service.dart';

class OrderHistoryScreen extends StatelessWidget {
  const OrderHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // คำนวณความกว้างหน้าจอเพื่อใช้จัดขนาดคอลัมน์อัตโนมัติ
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: const Text("รายงานยอดขาย (Admin)"),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.purple, Colors.blueAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService().getPurchaseHistory(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text("เกิดข้อผิดพลาด: ${snapshot.error}"));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.history_toggle_off, size: 64, color: Colors.grey),
                  SizedBox(height: 10),
                  Text("ยังไม่มีข้อมูลยอดขาย",
                      style: TextStyle(color: Colors.grey, fontSize: 18)),
                ],
              ),
            );
          }

          // คำนวณยอดขายรวมทั้งหมดจากข้อมูลที่ดึงมา
          double totalSales = 0;
          for (var order in snapshot.data!) {
            totalSales +=
                double.tryParse(order['total_price']?.toString() ?? '0') ?? 0;
          }

          return Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                  child: Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    child: ConstrainedBox(
                      // บังคับให้ตารางกว้างอย่างน้อยเท่ากับขนาดหน้าจอ
                      constraints: BoxConstraints(minWidth: screenWidth - 20),
                      child: DataTable(
                        columnSpacing: 15, // ระยะห่างระหว่างคอลัมน์แบบกระชับ
                        horizontalMargin: 10,
                        headingRowColor:
                            MaterialStateProperty.all(Colors.blueGrey.shade50),
                        columns: const [
                          DataColumn(
                              label: Text('วันที่/เวลา',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13))),
                          DataColumn(
                              label: Text('สินค้า',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13))),
                          DataColumn(
                              label: Text('จำนวน',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13))),
                          DataColumn(
                              label: Text('ราคารวม',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13))),
                        ],
                        rows: snapshot.data!.map((order) {
                          final double price = double.tryParse(
                                  order['total_price']?.toString() ?? '0') ??
                              0.0;
                          final String fullDate =
                              order['order_date']?.toString() ?? '-';

                          return DataRow(cells: [
                            // แสดงวันที่ครบถ้วน (รวมปี 2026) โดยลดขนาดฟอนต์เพื่อไม่ให้ล้น
                            DataCell(Text(fullDate,
                                style: const TextStyle(fontSize: 10.5))),

                            // ชื่อสินค้าจำกัดความกว้างป้องกันตัวหนังสือเบียด
                            DataCell(SizedBox(
                              width: screenWidth * 0.22,
                              child: Text(
                                  order['product_name']?.toString() ?? '-',
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500)),
                            )),

                            // จำนวนสินค้า
                            DataCell(Center(
                                child: Text("${order['qty'] ?? 0}",
                                    style: const TextStyle(fontSize: 12)))),

                            // ราคารวม (สีเขียวเข้มเพื่อให้อ่านง่ายบนพื้นขาว)
                            DataCell(Text("฿${price.toStringAsFixed(0)}",
                                style: const TextStyle(
                                    color: Colors.blueAccent,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12))),
                          ]);
                        }).toList(),
                      ),
                    ),
                  ),
                ),
              ),

              // แถบสรุปยอดขายรวมด้านล่าง
              Container(
                margin: const EdgeInsets.all(15),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black12,
                        blurRadius: 8,
                        spreadRadius: 2,
                        offset: const Offset(0, -2))
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("ยอดขายรวมทั้งหมด:",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold)),
                    Text("฿${totalSales.toStringAsFixed(2)}",
                        style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.green)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
